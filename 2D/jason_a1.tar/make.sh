#!/bin/bash
make
./main
